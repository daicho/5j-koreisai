export default function maxTranslate() {
  return -this.snapGrid[this.snapGrid.length - 1];
}
